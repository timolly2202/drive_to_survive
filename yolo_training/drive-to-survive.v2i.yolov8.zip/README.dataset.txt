# drive-to-survive > 2025-05-01 5:53pm
https://universe.roboflow.com/computer-vision-wppi7/drive-to-survive

Provided by a Roboflow user
License: CC BY 4.0

